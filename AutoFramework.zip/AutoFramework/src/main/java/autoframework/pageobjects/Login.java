package autoframework.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import autoframework.base.BasePage;
import autoframework.utilities.Util;

public class Login extends BasePage {
	
//	By inp_email=By.xpath("//input[@name='email']");
//	By inp_password=By.xpath("//input[@name='password']");
//	By btn_login=By.xpath("//button//span[contains(text(),'Log in')]");
//	By txt_alertBanner=By.xpath("//div[starts-with(@class,'alert-banner')]//h2");
	
	By inp_mobNumber=By.name("phone");
	By txt_error=By.xpath("//div[@class='loginCont']//p[contains(@class,'gr-redText')]");
	
	WebDriver driver;
	public Login(WebDriver driver)
	{
		super(driver);
		this.driver=driver;	
	}
	
	public void logWith(String phone)
	{
		getWebElement(inp_mobNumber).sendKeys(phone);
	}
	
	public boolean verifyErrorText()
	{
		Util.sleep(500);
		return getWebElement(txt_error).isDisplayed();
	}
	
	

}
