package autoframework.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import autoframework.base.BasePage;

public class Homepage extends BasePage {
	
	
//	By btn_login=By.xpath("//a[contains(@href,'login')]");
	
	By btn_signIn=By.id("get_sign_in");
	
	
	
	public Homepage(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
	}
	 public WebDriver driver;
	 
	 
	 public Login toLoginPage()
	 {
		 getWebElement(btn_signIn).click();
		 return new Login(driver);
		 
	 }

}
