package autoframework.base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import autoframework.driverfactory.WebDriverFactory;

public class BaseTest {
	 public WebDriver driver;
	
	 @BeforeClass
	    public void commonSetUp() {
	        driver = WebDriverFactory.getInstance().getDriver("chrome");
	        driver.get("https://www.goibibo.com/");
	    }

	    @AfterClass
	    public void commonTearDown() {
	        WebDriverFactory.getInstance().quitDriver();
	    }

}
