package autoframework.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import autoframework.base.BaseTest;
import autoframework.pageobjects.Homepage;
import autoframework.pageobjects.Login;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest extends BaseTest{
	
	@Test
	public void verifyErrorTextOnInvalidPhone()
	{
		Homepage homepage=new Homepage(driver);
		Login login=homepage.toLoginPage();
		login.logWith("Invalid@12");
		boolean isErrorDisplayed=login.verifyErrorText();
		Assert.assertTrue(isErrorDisplayed);
	}
	
	
	@Test
	public void goibi()
	{
		WebDriver driver = WebDriverManager.chromedriver().create();
		driver.get("https://www.goibibo.com/");
		WebElement city=driver.findElement(By.xpath("//*[text()='Enter city or airport']"));
		city.click();
		city.sendKeys("mumbai");
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@id='autoSuggest-list']"));
		for(WebElement e:ele )
		{
			int i=1;
			System.out.println(i);
			System.out.println(e.getText());
			i++;
			
		}
		
	}
}
